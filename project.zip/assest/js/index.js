alert("hello hari")

console.log('hai ')